minetest.register_alias("smartshop:wifistorage", "smartshop:storage")

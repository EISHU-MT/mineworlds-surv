
-- hidden nametag
minetest.register_privilege("hide_nametag", {
        description = "player nametag is hidden",
	give_to_singleplayer = false
})


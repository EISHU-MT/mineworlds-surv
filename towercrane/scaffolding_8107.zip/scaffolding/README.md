![zEdqwUZ.png](https://bitbucket.org/repo/B85zAq/images/958259462-zEdqwUZ.png)

 Say Goodbye To Dirt Scaffolding 

### About the Mod ###

Getting sick of using dirt as scaffolding? If so this is the mod for you.

This mod adds Wooden scaffolding and Iron scaffolding to minetest

The wooden and Iron scaffolding allows the player to go up and down like a ladder when the wooden and iron platforms allow you to wall along. If you want to remove the scaffolding just remove one or the bottom blocks to take the whole thing down.

> Wooden scaffolding is cheap and easy to make. However it can be destroyed by hand

> Iron scaffolding needs iron, but it cannot be destroyed by hand, and needs a pick.

> A Wrench can be used to reinforce your scaffolding. This will stop a long line of scaffolding to fall down. It you make the scaffolding reinforced you can remove it since reinforced scaffolding dose not make the whole lot fall down.

### How To Install ###

## Linux ##
1. Go to your Home directory
2. You should see a folder called minetest. If not the folder is probely hidden. To get to it type "/.minetest/" in the navigation bar.
3. You should now be in a folder called ".minetest". in this folder you should see another folder called "mods". If you dont see this make a new folder called "mods".
4.   Copy and Paste the mod into the "mods" folder. (make sure that it is extracted from the zip file". 

## Windows ##
1. Locate where the game has been saved. if you don't know where it has been saved right click the minetest icon and press "Open file location"
2. when you are in the minetest folder you should see a folder called "mods", as well as other folders like "bin", "textures" , "games", ect. 
3. Copy and Paste the mod into the "mods" folder. (make sure that it is extracted from the zip file". 

### More Info ###
[ website](http://thatraspberrypiserver.raspberryip.com/Infinatum_Minetest/scaffolding.html)